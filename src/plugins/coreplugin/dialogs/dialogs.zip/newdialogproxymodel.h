#ifndef NEWDIALOGPROXYMODEL_H
#define NEWDIALOGPROXYMODEL_H

#include <QAbstractProxyModel>
#include <QSortFilterProxyModel>
#include <QStandardItemModel>
namespace Core{
class IWizard;
class WizardModel: public QStandardItemModel
{
public:
	WizardModel(QObject *parent = 0);
	virtual ~WizardModel();
	void setWizards(QList<IWizard*> wizards);
	void addItem(QStandardItem *topLEvelCategoryItem, IWizard *wizard);
	QList<IWizard*> wizards(const QString &category);
	QList<IWizard*> wizards(const QModelIndex &parent);
protected:
	void getWizards(const QModelIndex& parent, QList<IWizard*> &wizards);
	QList<IWizard*> m_wizards;
	QIcon	m_dummyIcon;
};
class CategoryProxyModel : public QAbstractProxyModel
{
	Q_OBJECT

public:
	CategoryProxyModel(QObject *parent);
	~CategoryProxyModel();

	QModelIndex index(int row, int column, const QModelIndex &parent) const;

	QModelIndex parent(const QModelIndex &index) const;

	int rowCount(const QModelIndex &index) const;

	int columnCount(const QModelIndex &index) const;

	virtual QModelIndex	mapFromSource ( const QModelIndex & sourceIndex ) const;
	virtual QModelIndex	mapToSource ( const QModelIndex & proxyIndex ) const;
private:
	
};

class ItemProxyModel : public QAbstractProxyModel
{
	Q_OBJECT

public:
	ItemProxyModel(QObject *parent);
	~ItemProxyModel();

	QModelIndex index(int row, int column, const QModelIndex &parent) const;

	QModelIndex parent(const QModelIndex &index) const;

	int rowCount(const QModelIndex &index) const;

	int columnCount(const QModelIndex &index) const;

	virtual QModelIndex	mapFromSource ( const QModelIndex & sourceIndex ) const;
	virtual QModelIndex	mapToSource ( const QModelIndex & proxyIndex ) const;
private:

};
}

#endif // NEWDIALOGPROXYMODEL_H
